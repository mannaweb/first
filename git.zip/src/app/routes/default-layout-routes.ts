import { Routes } from '@angular/router';
import { AuthGuardService } from '../services/auth-guard.service';
import { LoginGuardService } from '../services/login-guard.service';

export const DEFAULT_ROUTES: Routes = [
    {
        path: '',
        loadChildren: () => import('../pages/product/product.module').then(m => m.ProductModule)
    },
    {
        path: 'product',
        loadChildren: () => import('../pages/product/product.module').then(m => m.ProductModule)
    },
    {
        path: 'product-details',
        loadChildren: () => import('../pages/product-details/product-details.module').then(m => m.ProductDetailsModule)
    },
    {
        path: 'lucky-box',
        loadChildren: () => import('../pages/lucky-box/lucky-box.module').then(m => m.LuckyBoxModule)
    },
    {
        path: 'cart',
        loadChildren: () => import('../pages/cart/cart.module').then(m => m.CartModule)
    },
    {
        path: 'checkout',
        loadChildren: () => import('../pages/checkout/checkout.module').then(m => m.CheckoutModule)
    },
    {
        path: 'aboutus',
        loadChildren: () => import('../pages/aboutus/aboutus.module').then(m => m.AboutusModule)
    },
    {
        path: 'privacy',
        loadChildren: () => import('../pages/privacy/privacy.module').then(m => m.PrivacyModule)
    },
    {
        path: 'terms',
        loadChildren: () => import('../pages/terms/terms.module').then(m => m.TermsModule)
    },
    {
        path: 'signin',
        loadChildren: () => import('../pages/signin/signin.module').then(m => m.SigninModule),
        canActivate: [LoginGuardService]
    },
    {
        path: 'signup',
        loadChildren: () => import('../pages/signup/signup.module').then(m => m.SignupModule),
        canActivate: [LoginGuardService]
    },
    {
        path: 'forgotpassword',
        loadChildren: () => import('../pages/forgotpwd/forgotpwd.module').then(m => m.ForgotpwdModule),
        canActivate: [LoginGuardService]
    },
    {
        path: 'user/account',
        loadChildren: () => import('../user/account/account.module').then(m => m.AccountModule),
        canActivate: [AuthGuardService]
    },
    {
        path: 'user/account-edit',
        loadChildren: () => import('../user/account-edit/account-edit.module').then(m => m.AccountEditModule),
        canActivate: [AuthGuardService]
    },
    {
        path: 'user/contact',
        loadChildren: () => import('../user/contact/contact.module').then(m => m.ContactModule),
        canActivate: [AuthGuardService]
    },
    {
        path: 'user/upcoming-events',
        loadChildren: () => import('../user/upcoming/upcoming.module').then(m => m.UpcomingModule),
        canActivate: [AuthGuardService]
    },
    {
        path: 'user/history',
        loadChildren: () => import('../user/history/history.module').then(m => m.HistoryModule),
        canActivate: [AuthGuardService]
    },
    {
        path: 'user/orders',
        loadChildren: () => import('../user/orders/orders.module').then(m => m.OrdersModule),
        canActivate: [AuthGuardService]
    },
    {
        path: 'user/order-details',
        loadChildren: () => import('../user/order-details/order-details.module').then(m => m.OrderDetailsModule),
        canActivate: [AuthGuardService]
    },
    {
        path: 'user/wishlist',
        loadChildren: () => import('../user/wishlist/wishlist.module').then(m => m.WishlistModule),
        canActivate: [AuthGuardService]
    },
    {
        path: 'user/change-password',
        loadChildren: () => import('../user/change-password/change-password.module').then(m => m.ChangePasswordModule),
        canActivate: [AuthGuardService]
    }

]