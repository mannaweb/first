import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { CalendarOptions } from '@fullcalendar/angular';

@Component({
  selector: 'app-upcoming',
  templateUrl: './upcoming.component.html',
  styleUrls: ['./upcoming.component.scss'],
	encapsulation:ViewEncapsulation.None
})
export class UpcomingComponent implements OnInit {
	csModal = '';
  constructor() { }
	
	calendarOptions: CalendarOptions = {
    initialView: 'dayGridMonth',
		eventClick: this.EventClick.bind(this),
    events: [
      { title: 'event 1', date: '2021-09-01' },
      { title: 'event 2', date: '2021-09-02' }
    ]
  };
	
	EventClick(arg: any) {
    //console.log(arg.event);
		this.csModal = 'active';
  }
	
	modalClose(){
		this.csModal = '';
	}
	
  ngOnInit(): void {
  }
}
