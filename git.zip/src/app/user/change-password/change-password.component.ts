import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { ApiService } from '../../services/api.service';
import { ToastrService } from '../../services/toastr.service';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.scss'],
	encapsulation:ViewEncapsulation.None
})
export class ChangePasswordComponent implements OnInit {
  passwordType: string = 'password';
	passwordTypeIclass: string = 'fas fa-fw fa-eye-slash';
  passwordType2: string = 'password';
	passwordTypeIclass2: string = 'fas fa-fw fa-eye-slash';
  passwordType3: string = 'password';
	passwordTypeIclass3: string = 'fas fa-fw fa-eye-slash';
  userId=localStorage.getItem('user_id');
  oldPassword: any = '';
  password: any = '';
  confirmPassword: any = '';
  isCpwd: any = false;
  constructor(
    public apiService: ApiService,
    public toastrService: ToastrService
  ) { }

  ngOnInit(): void {
  }

  changePwd() {
    this.isCpwd = true;
    this.apiService.postData('user/password-change', {userId: this.userId, oldPassword:this.oldPassword, newPassword:this.password, confirmPassword:this.confirmPassword}).subscribe( async (result) => {
      this.isCpwd = false;
      if (result['status'] == 200) {
        await this.toastrService.presentToast(result.message, 'success');
        this.oldPassword = '';
        this.password = '';
        this.confirmPassword = '';
      } else {
        this.toastrService.presentToast(result.message, 'error');
      }
    }, (error) => {
      this.isCpwd = false;
      console.log(error);
    })
  }

  changePasswordType() {
		if (this.passwordType == 'password') {
			this.passwordType = 'text';
			this.passwordTypeIclass = 'fas fa-fw fa-eye';
		} else {
			this.passwordType = 'password';
			this.passwordTypeIclass = 'fas fa-fw fa-eye-slash';
		}
	}

  changePasswordType2() {
		if (this.passwordType2 == 'password') {
			this.passwordType2 = 'text';
			this.passwordTypeIclass2 = 'fas fa-fw fa-eye';
		} else {
			this.passwordType2 = 'password';
			this.passwordTypeIclass2 = 'fas fa-fw fa-eye-slash';
		}
	}
  
  changePasswordType3() {
		if (this.passwordType3 == 'password') {
			this.passwordType3 = 'text';
			this.passwordTypeIclass3 = 'fas fa-fw fa-eye';
		} else {
			this.passwordType3 = 'password';
			this.passwordTypeIclass3 = 'fas fa-fw fa-eye-slash';
		}
	}

}
