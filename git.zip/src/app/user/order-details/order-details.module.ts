import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { OrderDetailsRoutingModule } from './order-details-routing.module';
import { OrderDetailsComponent } from './order-details.component';
import { SidebarModule } from '../../component/sidebar/sidebar.module';
import { OrderDetailsLoaderModule } from '../../component/order-details-loader/order-details-loader.module';


@NgModule({
  declarations: [
    OrderDetailsComponent
  ],
  imports: [
    CommonModule,
    RouterModule,
    SidebarModule,
    NgbModule,
    OrderDetailsRoutingModule,
    OrderDetailsLoaderModule
  ]
})
export class OrderDetailsModule { }
