import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { Router, ActivatedRoute } from '@angular/router';
import { ApiService } from '../../services/api.service';
import { ToastrService } from '../../services/toastr.service';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-order-details',
  templateUrl: './order-details.component.html',
  styleUrls: ['./order-details.component.scss'],
	encapsulation:ViewEncapsulation.None
})
export class OrderDetailsComponent implements OnInit {
  userId=localStorage.getItem('user_id');
  productDefaultImg:any = environment.productDefaultImg;
  is_data: any = 2;
  orderId:any = '';
  orderDetails: any = [];
  orderData:any = [];
  isOpen:any = false;
  closeResult = '';
  loaderImage:any = 'assets/img/load-loading.gif';
  is_open:any = 2;
  mysteryBoxDetails:any = [];
  winImage:any = '';
  winProductname:any = '';
  totalAmount:any = '0';
  constructor(
    private modalService: NgbModal,
    public router:Router, 
    public route: ActivatedRoute,
    public apiService: ApiService,
    public toastrService: ToastrService
  ) { }

  ngOnInit(): void {
    this.route.queryParamMap.subscribe(params =>{
      this.orderId = params.get('orderno');
      if(this.orderId){
        this.getOrderDetailst();
      }
    });
  }

  getOrderDetailst(){
		this.apiService.postData('order/orderDetails',{user_id : this.userId,orderId:this.orderId}).subscribe((result)=>{
			if (result['status'] == 200){
				this.orderDetails = result['data'];
        this.orderData = result['data'].info; 
        this.totalAmount = (parseFloat(result['data'].total_amount)+parseFloat(result['data'].tax)+parseFloat(result['data'].shipping_charge)).toFixed(2);
			} 
			this.is_data = 1;     
		},(error)=>{
			console.log(error);
		})
  }

  handleProductImgError(ev: any){
		const source = ev.srcElement;
		source.src = this.productDefaultImg;
	}

  openModal(openmistrybox: any,order_id:any,product_id:any,id:any,index:any){
    this.loaderImage = 'assets/img/load-loading.gif';  
    this.modalService.open(openmistrybox, { centered: true,size:'lg' } ).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
      this.getOrderDetailst();
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
      this.getOrderDetailst();
    });
    //
    //*********** Calling Api
    let data={
      productId:product_id,
      userId:this.userId
    }
    this.apiService.postData('product/details',data).subscribe((result)=>{
			if (result['status'] == 200) {
        this.mysteryBoxDetails = result['data'].MysteryBoxDetails;
			} 
      this.is_open = 2;     
		},(error)=>{
			console.log(error);
		})
    //*********** Open Mystery Box
    this.apiService.postData('mystery-box/open-mystery-box',{orderId:order_id,orderDetailsId:id}).subscribe((result)=>{
			if (result['status'] == 200) {
        this.winImage = result['data'].product_details.image;
        this.winProductname = result['data'].product_name;
        //this.orderDetails
			} 
      this.is_open = 1;     
		},(error)=>{
			console.log(error);
		})
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

}
