import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import {NgbAccordionConfig} from '@ng-bootstrap/ng-bootstrap';
import { ApiService } from '../../services/api.service';
import { ToastrService } from '../../services/toastr.service';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-orders',
  templateUrl: './orders.component.html',
  styleUrls: ['./orders.component.scss'],
	encapsulation:ViewEncapsulation.None
})
export class OrdersComponent implements OnInit {
  productDefaultImg: any = environment.productDefaultImg;
  userId:any = localStorage.getItem('user_id');
  orderRequestList: any = {
    userId: localStorage.getItem('user_id'),
    limit: 8,
    lastId: '',
    orderBy: 'id',
    order: 'DESC',
    keyword: '',
    status: ''
  };
  orderList: any = [];
  is_data: any = 2;
  isProssing:any = false;
  ishidden:any = 2;
  constructor(
    config: NgbAccordionConfig,
    public apiService: ApiService,
    public toastrService: ToastrService
    ) {
    config.closeOthers = false;
    config.type = 'info';
   }

  ngOnInit(): void {
    this.getOrderList();
  }

  getOrderList(){
    this.ishidden = 1;
    this.apiService.postData('order/list',this.orderRequestList).subscribe((result)=>{
      if (result['status'] == 200) {
        this.orderList = result['data'];
        if (this.orderList.length > 0) {
          this.orderRequestList.lastId = this.orderList[this.orderList.length - 1].id;
        }
      }
      if(result['count'] <= 8){
        this.ishidden = 1;
      }else{
        this.ishidden = 2;
      }
      this.is_data = 1;
		},(error)=>{
			console.log(error);
		})
  }

  loadmore(){
    this.isProssing = true;
    this.apiService.postData('order/list',this.orderRequestList).subscribe((result)=>{
			if (result['status'] == 200) {
          this.isProssing = false;
          if(result['data'].length <= 8){                    
            this.ishidden = 1;
          }
          this.orderList.push(...result['data']);
        if (this.orderList.length > 0){                    
          this.orderRequestList.lastId = this.orderList[this.orderList.length - 1].id;
        }        
			}
		},(error)=>{
			console.log(error);
		})
  }

  handleProductImgError(ev: any) {
		const source = ev.srcElement;
		source.src = this.productDefaultImg;
	}

}
