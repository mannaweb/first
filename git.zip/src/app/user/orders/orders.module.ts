import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { OrdersRoutingModule } from './orders-routing.module';
import { OrdersComponent } from './orders.component';
import { SidebarModule } from '../../component/sidebar/sidebar.module';
import { OrdersLoaderModule } from '../../component/orders-loader/orders-loader.module';



@NgModule({
  declarations: [
    OrdersComponent
  ],
  imports: [
    CommonModule,
    SidebarModule,
    RouterModule,
    OrdersRoutingModule,
    NgbModule,
    OrdersLoaderModule
  ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})
export class OrdersModule { }
