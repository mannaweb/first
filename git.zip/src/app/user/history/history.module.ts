import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { HistoryRoutingModule } from './history-routing.module';
import { HistoryComponent } from './history.component';
import { SidebarModule } from '../../component/sidebar/sidebar.module';
import { HistoryLoaderModule } from '../../component/history-loader/history-loader.module';


@NgModule({
  declarations: [
    HistoryComponent
  ],
  imports: [
    CommonModule,
    SidebarModule,
    RouterModule,
    HistoryRoutingModule,
    NgbModule,
    HistoryLoaderModule
  ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})
export class HistoryModule { }
