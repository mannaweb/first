import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { ApiService } from '../../services/api.service';
import { ToastrService } from '../../services/toastr.service';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-history',
  templateUrl: './history.component.html',
  styleUrls: ['./history.component.scss'],
	encapsulation:ViewEncapsulation.None
})
export class HistoryComponent implements OnInit {
  productDefaultImg: any = environment.productDefaultImg;
  userId:any = localStorage.getItem('user_id');
  historyRequestList: any = {
    userId: localStorage.getItem('user_id'),
    limit: 8,
    orderBy: 'id',
    order: 'DESC',
    lastId: ''
  };
  historyList: any = [];
  is_data: any = 2;
  isProssing:any = false;
  ishidden:any = 2;
  constructor(
    public apiService: ApiService,
    public toastrService: ToastrService
  ) {}

  ngOnInit(): void {
    this.getHistoryList();
  }

  getHistoryList(){
    this.apiService.postData('browsing-history/list',this.historyRequestList).subscribe((result)=>{
			if (result['status'] == 200) {
        this.historyList = result['data'];
        if (this.historyList.length > 0) {
          this.historyRequestList.lastId = this.historyList[this.historyList.length - 1].id;
        }        
			}
      
      if(result['count'] <= 9){
        this.ishidden = 1;
      }
      this.is_data = 1;
		},(error)=>{
			console.log(error);
		})
  }

  loadmore(){
    this.isProssing = true;
    this.apiService.postData('product/list',this.historyRequestList).subscribe((result)=>{
			if (result['status'] == 200) {
          this.isProssing = false;
          if(result['data'].length <= 9){                    
            this.ishidden = 1;
          }
          this.historyList.push(...result['data']);
        if (this.historyList.length > 0){                    
          this.historyRequestList.lastId = this.historyList[this.historyList.length - 1].id;
        }        
			}
		},(error)=>{
			console.log(error);
		})
  }

  handleProductImgError(ev: any) {
		const source = ev.srcElement;
		source.src = this.productDefaultImg;
	}

}
