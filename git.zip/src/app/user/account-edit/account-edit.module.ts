import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule } from '@angular/forms';
import { AccountEditRoutingModule } from './account-edit-routing.module';
import { AccountEditComponent } from './account-edit.component';
import { SidebarModule } from '../../component/sidebar/sidebar.module';
import { NgxDaterangepickerMd } from 'ngx-daterangepicker-material';

@NgModule({
  declarations: [
    AccountEditComponent
  ],
  imports: [
    CommonModule,
    AccountEditRoutingModule,
		SidebarModule,
		RouterModule,
		NgbModule,
    FormsModule,
    NgxDaterangepickerMd.forRoot({
      format: 'YYYY-MM-DD', // could be 'YYYY-MM-DDTHH:mm:ss.SSSSZ'
      displayFormat: 'YYYY-MM-DD'
    })
  ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})
export class AccountEditModule { }
