import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {ApiService} from '../../services/api.service';
import { ToastrService } from '../../services/toastr.service';
import {environment} from '../../../environments/environment';

@Component({
  selector: 'app-account-edit',
  templateUrl: './account-edit.component.html',
  styleUrls: ['./account-edit.component.scss'],
	encapsulation:ViewEncapsulation.None
})

export class AccountEditComponent implements OnInit {
  defaultImg:any=environment.userDefaultImg;
  profileDetails: any = [];
  profileEditData:any= {
    'userId':'',
    'fname':'',
    'lname':'',
    'phone':'',
    'email':'',
    'dob':'',
    "billing_address_1" : '',
    "billing_address_2" : '',
    "billing_city" : '',
    "billing_state" : '',
    "billing_zipcode" : '',
    "mailing_address_1" : '',
    "mailing_address_2" : '',
    "mailing_city" : '',
    "mailing_state" : '',
    "mailing_zipcode" : '',
    'image':''
  };
  userId=localStorage.getItem('user_id');
  images:any;
  isProfileEdit: any = false;
  selected:any = '';  
  constructor(
    public router:Router,
    public route: ActivatedRoute,
    public apiService:ApiService,
    public toastrService: ToastrService
  ) { }

  ngOnInit(): void {
    this.getProfile();
  }

  getProfile(){
    let data={
      userId:this.userId
    }
    this.apiService.postData('user/details',data).subscribe((result)=>{
			if (result['status'] == 200) {
        this.profileDetails = result['data'].userdetails;
			  this.profileEditData.userId = this.userId;
        this.profileEditData.fname = result['data'].userdetails.fname;
        this.profileEditData.lname = result['data'].userdetails.lname;
        this.profileEditData.email = result['data'].userdetails.email;
        this.profileEditData.phone = result['data'].userdetails.phone;
        this.profileEditData.dob = result['data'].userdetails.dob;  
        this.profileEditData.billing_address_1 = result['data'].userdetails.billing_address_1; 
        this.profileEditData.billing_address_2 = result['data'].userdetails.billing_address_2;
        this.profileEditData.billing_city = result['data'].userdetails.billing_city;
        this.profileEditData.billing_zipcode = result['data'].userdetails.billing_zipcode;  
        this.profileEditData.mailing_address_1 = result['data'].userdetails.address;
        this.profileEditData.mailing_address_2 = result['data'].userdetails.address_2;
        this.profileEditData.mailing_city = result['data'].userdetails.city;
        this.profileEditData.mailing_zipcode = result['data'].userdetails.zip_code;   
			  this.images = this.profileDetails.picture;
        this.selected = result['data'].userdetails.dob;
			} else {
        
			}
		},(error)=>{
			console.log(error);
		})
  }

  updateProfileDetails(){
    this.isProfileEdit = true;
    this.apiService.postData('user/profile-update',this.profileEditData).subscribe((result)=>{
      this.isProfileEdit = false;
			if (result['status'] == 200) {
        this.toastrService.presentToast(result.message, 'success');
			} else {
        this.toastrService.presentToast(result.message, 'error');
			}
		},(error)=>{
      this.isProfileEdit = false;
			console.log(error);
		})
  }

  onFileSelected(event:any) {
		let file = event.target.files[0];
		this.getBase64(file);
	}
	getBase64(file: Blob) {
		let me = this;
		var reader = new FileReader();
		reader.readAsDataURL(file);
		reader.onload = function () {
			me.images = reader.result;
			me.profileEditData.image = reader.result;
		};
		reader.onerror = function (error) {
			console.log('Error: ', error);
		};
	}

  handleImgError(ev: any){
		let source = ev.srcElement;
		source.src = this.defaultImg;
	}

}
