import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { ApiService } from '../../services/api.service';
import { ToastrService } from '../../services/toastr.service';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-account',
  templateUrl: './account.component.html',
  styleUrls: ['./account.component.scss'],
	encapsulation:ViewEncapsulation.None
})
export class AccountComponent implements OnInit {
  userDefaultImg: any = environment.userDefaultImg;
  productDefaultImg:any = environment.productDefaultImg;
  userId=localStorage.getItem('user_id');
  userdetails: any = [];
  is_data:any = 2;
  orderList: any = [];
  wishList: any = [];
  browsingHistorylist: any = [];
  noOrderData:any = 2;
  noWishlistData:any = 2;
  noBrowsingHistoryData:any = 2;
  constructor(
    public apiService: ApiService,
    public toastrService: ToastrService
  ) { }

  ngOnInit(): void {
    this.getProfile();    
    this.getRecentOrder();
    this.getRecentWishlist();
    this.getRecentBrowsHistory();
  }

  getProfile(){
    let data={
      userId:this.userId
    }
    this.apiService.postData('user/details',data).subscribe((result)=>{
			if (result['status'] == 200) {
        this.userdetails = result['data'].userdetails;
			}
      this.is_data = 1;
		},(error)=>{
			console.log(error);
		})
  }

  getRecentOrder(){
    let orderData={
      userId:this.userId,
      limit: "4",
      orderBy:'id',
      order: "DESC",
      start: ""
    }
    this.apiService.postData('order/list',orderData).subscribe((result)=>{
      this.orderList = result['data'];
      if(this.orderList.length>0){
        this.noOrderData = 1;
      }
		},(error)=>{
			console.log(error);
		})
  }

  getRecentWishlist(){
    let wishlist={
      userId:this.userId,
      limit: "4",
      orderBy:'id',
      order: "DESC",
      start: ""
    }
    this.apiService.postData('wishlist/list',wishlist).subscribe((result)=>{
      this.wishList = result['data'];
      if(this.wishList.length>0){
        this.noWishlistData = 1;
      }
		},(error)=>{
			console.log(error);
		})
  }

  getRecentBrowsHistory(){
    let browsinglist={
      userId:this.userId,
      limit: "4",
      orderBy:'id',
      order: "DESC",
      start: ""
    }
    this.apiService.postData('browsing-history/list',browsinglist).subscribe((result)=>{
      this.browsingHistorylist = result['data'];
      if(this.browsingHistorylist.length>0){
        this.noBrowsingHistoryData = 1;
      }
		},(error)=>{
			console.log(error);
		})
  }

  removeWishList(product_id:any,index: any){
    let data={
      userId:this.userId,
      product_id:product_id
    }
    this.apiService.postData('wishlist/add',data).subscribe((result)=>{
			if (result['status'] == 200) {
        //this.wishList.splice(index, 1);
        this.getRecentWishlist();
        this.toastrService.presentToast(result.message, 'success');
			}else{
        this.toastrService.presentToast(result.message, 'error');
      }
      this.is_data = 1;
		},(error)=>{
			console.log(error);
		})
  }

  handleImgError(ev: any) {
		const source = ev.srcElement;
		source.src = this.userDefaultImg;
	}

  handleProductImgError(ev: any) {
		const source = ev.srcElement;
		source.src = this.productDefaultImg;
	}

}
