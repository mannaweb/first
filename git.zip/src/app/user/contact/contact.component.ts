import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { ApiService } from '../../services/api.service';
import { ToastrService } from '../../services/toastr.service';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.scss'],
	encapsulation:ViewEncapsulation.None
})
export class ContactComponent implements OnInit {
  productDefaultImg: any = environment.productDefaultImg;
	userDefaultImg: any = environment.userDefaultImg;
  userId=localStorage.getItem('user_id');
  relationshipList: any = [];
  stateList: any = [];
  frequencyList: any = [];
  contactData: any = {
    image:'',
    user_id:localStorage.getItem('user_id'),
    first_name:'',
    last_name:'',
    email:'',
    phone:'',
    relationship:'',
    relationship_id:'',
    dob:'',
    gender:'',
    budget:'',
    address_1:'',
    address_2:'',
    city:'',
    state:'',
    zipcode:'',
    hobby:[],
    events:[{
        event_name:'',
        event_date:'',
        frequency:'',
        frequency_id:''
      }],
    note:''
  };
  isAdd: any = false;
  contactList: any = [];
  contactRequestList: any = {
    userId: localStorage.getItem('user_id'),
    limit: 10,
    start: '',
    orderBy: '',
    order: '',
    keyword: '',
    status: ''
  };
  contactId: any;
  is_data:any = 2;
  contactOrderList:any = [];
  contactPerson:any = '';
  productImage:any = 'assets/img/load-loading.gif';
  is_load:any = 1;
  constructor(
    private modalService: NgbModal,
    public apiService: ApiService,
    public toastrService: ToastrService
    ) { }

  ngOnInit(): void {
    this.getContact();
    this.getRelationship();
    this.getFrequency();
  }

  openEdit(content: any){    
    this.contactId = '';
    this.contactData = {
      user_id:localStorage.getItem('user_id'),
      first_name:'',
      last_name:'',
      email:'',
      phone:'',
      relationship:'',
      relationship_id:'',
      dob:'',
      gender:'',
      budget:'',
      address_1:'',
      address_2:'',
      city:'',
      state:'',
      zipcode:'',
      hobby:[],
      events:[{
        event_name:'',
        event_date:'',
        frequency:'',
        frequency_id:''
      }],
      note:''
    };
    this.modalService.open(content, { centered: true, windowClass: 'manage-contact' });
  }  

  editContact(content: any,id: any){
    this.contactId = id;
    this.contactData.id = id;
    this.apiService.postData('contacts/details',{contact_id:id, user_id: this.userId}).subscribe((result)=>{
			if (result['status'] == 200) {
        this.contactData.image = result['data'].image;
        this.contactData.first_name = result['data'].first_name;
        this.contactData.last_name = result['data'].last_name;
        this.contactData.email = result['data'].email;
        this.contactData.phone = result['data'].phone;
        this.contactData.relationship_id = result['data'].relationship_id;
        let index = this.relationshipList.findIndex( (item: any) => item.id == this.contactData.relationship_id );
        if(index >= 0){
          this.contactData.relationship = this.relationshipList[index].name;
        }
        this.contactData.dob = result['data'].dob;
        this.contactData.gender = (result['data'].gender == 1)?'male':'female';
        this.contactData.budget = result['data'].budget;
        this.contactData.address_1 = result['data'].address_1;
        this.contactData.address_2 = result['data'].address_2;
        this.contactData.city = result['data'].city;
        this.contactData.state = result['data'].state;
        this.contactData.zipcode = result['data'].zipcode;
        this.contactData.hobby = (result['data'].hobbies)?result['data'].hobbies.split(','):[];
        if(result['data'].events.length > 0){
          for (let index = 0; index < result['data'].events.length; index++) {
            const element = result['data'].events[index];
            let frequencyIndex = this.frequencyList.findIndex( (item: any) => item.id == element.frequency_id );
            let frequency = '';
            if(frequencyIndex >= 0){
              frequency = this.frequencyList[frequencyIndex].name;
            }
            this.contactData.events.push({
              event_name:element.event_name,
              event_date:element.event_date,
              frequency:frequency,
              frequency_id:element.frequency_id
            })
          }
        }
        this.contactData.note = result['data'].note;
        this.contactData.oldImage =  result['data'].image;
        this.modalService.open(content, { centered: true, windowClass: 'manage-contact' });
			}
		},(error)=>{
			console.log(error);
		})
  }
  
	openHistory(content: any,contactId:any){
    this.productImage = 'assets/img/load-loading.gif';
    this.is_load = 1;
    this.modalService.open(content, { centered: true, windowClass: 'order-history' });
    this.apiService.postData('order/contact-order-list',{'contactId':contactId,'limit':''}).subscribe((result)=>{
			if (result['status'] == 200) {    
        this.contactPerson = result['data'].contact_name;   
        this.contactOrderList = result['data'].order_list;        
			}
      this.is_load = 2;
		},(error)=>{
			console.log(error);
		})
    
  }

  handleProductImgError(ev: any) {
		const source = ev.srcElement;
		source.src = this.productDefaultImg;
	}

  onFileSelected(event:any) {
		let file = event.target.files[0];
		this.getBase64(file);
	}
	getBase64(file: Blob) {
		let me = this;
		var reader = new FileReader();
		reader.readAsDataURL(file);
		reader.onload = function () {
			me.contactData.image = reader.result;
		};
		reader.onerror = function (error) {
			console.log('Error: ', error);
		};
	}

  getContact(){
    this.apiService.postData('contacts/list',this.contactRequestList).subscribe((result)=>{
			if (result['status'] == 200) {
        if(result['data'].length > 0){
          result['data'].map((item: any) => {
            item.hobbies = (item.hobbies)?item.hobbies.split(','):[];
          });
        }
        this.contactList = result['data'];
			}
      this.is_data = 1;
		},(error)=>{
			console.log(error);
		})
  }

  getRelationship(){
    let data={
      user_id:this.userId
    }
    this.apiService.postData('relationships-list',data).subscribe((result)=>{
			if (result['status'] == 200) {
        this.relationshipList = result['data'];
			}
		},(error)=>{
			console.log(error);
		})
  }

  getState(){
    let data={
      userId:this.userId
    }
    this.apiService.postData('user/details',data).subscribe((result)=>{
			if (result['status'] == 200) {
        this.stateList = result['data'].userdetails;
			}
		},(error)=>{
			console.log(error);
		})
  }

  getFrequency(){
    let data={
      userId:this.userId
    }
    this.apiService.postData('frequency-list',data).subscribe((result)=>{
			if (result['status'] == 200) {
        this.frequencyList = result['data'];
			}
		},(error)=>{
			console.log(error);
		})
  }

  selectRelationship(id: any, name: any){
    this.contactData.relationship_id = id;
    this.contactData.relationship = name;
  }

  selectFrequency(id: any, name: any, i: any){
    this.contactData.events[i].frequency_id = id;
    this.contactData.events[i].frequency = name;
  }

  addEvent(){
    this.contactData.events.push({event_name:'', event_date:'', frequency:'', frequency_id:''})
  }

  removeEvent(i: any){
    this.contactData.events.splice(i,1);
  }

  addContact(){
    this.isAdd = true;
    this.apiService.postData('contacts/save-data', this.contactData).subscribe( async (result) => {
      this.isAdd = false;
      if (result['status'] == 200) {
        await this.toastrService.presentToast(result.message, 'success');
        this.contactData = {
          user_id:localStorage.getItem('user_id'),
          first_name:'',
          last_name:'',
          email:'',
          phone:'',
          relationship:'',
          relationship_id:'',
          dob:'',
          gender:'',
          budget:'',
          address_1:'',
          address_2:'',
          city:'',
          state:'',
          zipcode:'',
          hobby:[],
          events:[{
            event_name:'',
            event_date:'',
            frequency:'',
            frequency_id:''
          }],
          note:''
        };
      } else {
        this.toastrService.presentToast(result.message, 'error');
      }
    }, (error) => {
      this.isAdd = false;
      console.log(error);
    })
  }

  handleImgError(ev: any) {
		const source = ev.srcElement;
		source.src = this.userDefaultImg;
	}

}
