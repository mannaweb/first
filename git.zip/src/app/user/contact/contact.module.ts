import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgxDaterangepickerMd } from 'ngx-daterangepicker-material';

import { ContactRoutingModule } from './contact-routing.module';
import { ContactComponent } from './contact.component';
import { SidebarModule } from '../../component/sidebar/sidebar.module';
import { FormsModule } from '@angular/forms';
import { TagInputModule } from 'ngx-chips';
import { ContactLoaderModule } from '../../component/contact-loader/contact-loader.module';


@NgModule({
  declarations: [
    ContactComponent
  ],
  imports: [
    CommonModule,
    RouterModule,
		SidebarModule,
    ContactRoutingModule,
    NgbModule,
    FormsModule,
    NgxDaterangepickerMd.forRoot(),
    TagInputModule,
    ContactLoaderModule
  ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})
export class ContactModule { }
