import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { ApiService } from '../../services/api.service';
import { ToastrService } from '../../services/toastr.service';
import { environment } from '../../../environments/environment';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-wishlist',
  templateUrl: './wishlist.component.html',
  styleUrls: ['./wishlist.component.scss'],
	encapsulation:ViewEncapsulation.None
})
export class WishlistComponent implements OnInit {
  productDefaultImg: any = environment.productDefaultImg;
  userId:any = localStorage.getItem('user_id');
  wishlistRequestList: any = {
    userId: localStorage.getItem('user_id'),
    limit: 8,
    lastId:'',
    orderBy: '',
    order: '',
    keyword: '',
    status: ''
  };
  wishList: any = [];
  isWishlistRemoved: any = false;
  is_data: any = 2;
  quantity:any = 1;
  closeResult = '';
  isCart:any = false;
  productId:any = '';
  contactId:any = '';
  countCart:any= 0;
  defaultContact:any = 'Select Contact';
  contactsList:any = [];
  productName:any = '';
  defaultEvent:any = 'Select Event';
  eventList:any = [];
  eventId:any='';
  isProssing:any = false;
  ishidden:any = 2;
  constructor(
    private modalService: NgbModal,
    public router:Router, 
    public route: ActivatedRoute,
    public apiService: ApiService,
    public toastrService: ToastrService
  ) { }

  ngOnInit(): void {
    this.getWishList();
    this.getContacts();
  }

  getWishList(){
    this.ishidden = 1;
    this.apiService.postData('wishlist/list',this.wishlistRequestList).subscribe((result)=>{
			if (result['status'] == 200) {
        this.wishList = result['data'];
        if (this.wishList.length > 0) {
          this.wishlistRequestList.lastId = this.wishList[this.wishList.length - 1].id;
        }        
			}
      if(result['count'] <= 8){
        this.ishidden = 1;
      }else{
        this.ishidden = 2;
      }      
      this.is_data = 1;
		},(error)=>{
			console.log(error);
		})
  }

  loadmore(){
    this.isProssing = true;
    this.apiService.postData('wishlist/list',this.wishlistRequestList).subscribe((result)=>{
			if (result['status'] == 200) {
          this.isProssing = false;
          if(result['data'].length < 8){                    
            this.ishidden = 1;
          }
          this.wishList.push(...result['data']);
        if (this.wishList.length > 0){                    
          this.wishlistRequestList.lastId = this.wishList[this.wishList.length - 1].id;
        }        
			}
		},(error)=>{
			console.log(error);
		})
  }

  removeWishList(product_id: any, index: any){
    this.isWishlistRemoved = true; 
    this.apiService.postData('wishlist/add',{userId:this.userId, product_id: product_id}).subscribe((result)=>{
			if (result['status'] == 200) {
        this.wishList.splice(index, 1);
        this.toastrService.presentToast(result.message, 'success');
			}else{
        this.toastrService.presentToast(result.message, 'error');
      }
    this.isWishlistRemoved = false; 
		},(error)=>{
			console.log(error);
		})
  }

  getContacts(){
    let data={
      userId:this.userId,
      limit: 30,
      start : '',
      orderBy: 'id',
      order : 'DESC'
    }
    this.apiService.postData('contacts/list',data).subscribe((result)=>{
			if (result['status'] == 200) {
        this.contactsList = result['data'];
			}  
		},(error)=>{
			console.log(error);
		})
  }


  addToCart(){
    this.isCart = true;
    let data = {
      userId:this.userId,
      productId:this.productId,
      contactId : this.contactId,
      eventId : this.eventId,
      quantity : this.quantity
    }
    if(this.userId !='' && this.userId !=null){
      this.apiService.postData('add-cart',data).subscribe((result)=>{
        if (result['status'] == 200) {
          this.countCart = result['total'];
          this.closeResult = `Closed with: ${result}`;
          this.toastrService.presentToast(result.message, 'success');
        }else{
          this.toastrService.presentToast(result.message, 'error');
        }
        this.isCart = false;
      },(error)=>{
        this.isCart = false;
        console.log(error);
      })
    }else{
      this.router.navigateByUrl('/signin')
    }
    
  }

  chooseContact(id:any,fname:any,lname:any){
    this.contactId =id;
	  this.defaultContact = fname+' '+lname;
    this.getEvents();
  }

  getEvents(){
    let data={
      contactId:this.contactId
    }
    this.apiService.postData('contact-wise-events',data).subscribe((result)=>{
			if (result['status'] == 200) {
        this.eventList = result['data'];
			}  
		},(error)=>{
			console.log(error);
		})
  }

  chooseEvent(id:any,name:any){
    this.eventId = id;
	  this.defaultEvent = name;
  }
  

  handleProductImgError(ev: any) {
		const source = ev.srcElement;
		source.src = this.productDefaultImg;
	}

  contactModal(cart: any,id:any,name:any){
    if(this.userId !='' && this.userId !=null){
      this.productName = name;
      this.productId = id;
      this.modalService.open(cart, { centered: true } ).result.then((result) => {
        this.closeResult = `Closed with: ${result}`;
      }, (reason) => {
        this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
      });
    }else{
      this.router.navigateByUrl('/signin')
    }
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

}
