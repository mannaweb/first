import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { WishlistRoutingModule } from './wishlist-routing.module';
import { WishlistComponent } from './wishlist.component';
import { SidebarModule } from '../../component/sidebar/sidebar.module';
import { WishlistLoaderModule } from '../../component/wishlist-loader/wishlist-loader.module';


@NgModule({
  declarations: [
    WishlistComponent
  ],
  imports: [
    CommonModule,
    SidebarModule,
    RouterModule,
    WishlistRoutingModule,
    NgbModule,
    WishlistLoaderModule
  ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})
export class WishlistModule { }
