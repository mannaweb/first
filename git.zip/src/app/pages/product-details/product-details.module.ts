import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ProductDetailsRoutingModule } from './product-details-routing.module';
import { ProductDetailsLoaderModule } from '../../component/product-details-loader/product-details-loader.module';
import { ProductDetailsReviewLoaderModule } from '../../component/product-details-review-loader/product-details-review-loader.module';
import { ProductDetailsComponent } from './product-details.component';
import { FormsModule } from '@angular/forms';


@NgModule({
  declarations: [
    ProductDetailsComponent
  ],
  imports: [
    CommonModule,
    NgbModule,
    ProductDetailsRoutingModule,
    ProductDetailsLoaderModule,
    ProductDetailsReviewLoaderModule,
    FormsModule
  ]
})
export class ProductDetailsModule { }
