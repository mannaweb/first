import { Component, OnInit,Input, ViewEncapsulation } from '@angular/core';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { Router, ActivatedRoute } from '@angular/router';
import { ApiService } from '../../services/api.service';
import { ToastrService } from '../../services/toastr.service';
import { environment } from '../../../environments/environment';
import { EventsService } from '../../services/events.service';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ProductDetailsComponent implements OnInit {
  userId=localStorage.getItem('user_id');
  productDefaultImg:any = environment.productDefaultImg;
  productDetails: any = [];
  productImage: any = [];
  mysteryBoxDetails:any = [];
  productId:any = '';
  is_data: any = 2;
  bigimage:any = '';
  productReview:any = [];
  is_review:any = 2;
  quantity:any = 1;
  browserHistoryDetails:any = [];
  contactsList:any = [];
  defaultContact:any = 'Select Contact';
  contactId:any = '';
  closeResult = '';
  countCart:any= 0;
  isCart:any = false;
  defaultEvent:any = 'Select Event';
  eventList:any = [];
  eventId:any='';
  constructor(
    private modalService: NgbModal,
    public router:Router, 
    public route: ActivatedRoute,
    public apiService: ApiService,
    public toastrService: ToastrService,
    private events: EventsService
  ) { }

  ngOnInit(): void {
    this.route.queryParamMap.subscribe(params => {
      this.productId = params.get('product');
      if(this.productId){
        this.getProduct();
        this.getReviews();
        this.getContacts();
      }
    });
    if(this.userId !=''){
      this.apiService.postData('browsing-history/add',{userId:this.userId,productId:this.productId}).subscribe((result)=>{
        if (result['status'] == 200) {
          this.browserHistoryDetails = result['data'];
        } 
        this.is_data = 1;     
      },(error)=>{
        console.log(error);
      })
    }

  }

  getProduct(){
    let data={
      productId:this.productId,
      userId:this.userId
    }
    this.apiService.postData('product/details',data).subscribe((result)=>{
			if (result['status'] == 200) {
        this.productDetails = result['data'].ProductDetails;
        this.productImage = result['data'].ProductImages;
        this.bigimage = result['data'].ProductImages[0].image;
        this.mysteryBoxDetails = result['data'].MysteryBoxDetails;
			} 
      this.is_data = 1;     
		},(error)=>{
			console.log(error);
		})
  }

  getReviews(){
    let data={
      productId:this.productId,
      limit: 4,
      start : '',
      orderBy: 'id',
      order : 'DESC'
    }
    this.apiService.postData('list-review',data).subscribe((result)=>{
			if (result['status'] == 200) {
        this.productReview = result['data'];
			} 
      this.is_review = 1;     
		},(error)=>{
			console.log(error);
		})
  }

  getContacts(){
    let data={
      userId:this.userId,
      limit: 30,
      start : '',
      orderBy: 'id',
      order : 'DESC'
    }
    this.apiService.postData('contacts/list',data).subscribe((result)=>{
			if (result['status'] == 200) {
        this.contactsList = result['data'];        
			}  
		},(error)=>{
			console.log(error);
		})
  }

  getEvents(){
    let data={
      contactId:this.contactId
    }
    this.apiService.postData('contact-wise-events',data).subscribe((result)=>{
			if (result['status'] == 200) {
        this.eventList = result['data'];
			}  
		},(error)=>{
			console.log(error);
		})
  }

  seeImage(image:any){
    this.bigimage = image;
  }

  manageFavourite(product_id:any){
    let data={
      userId:this.userId,
      product_id:product_id
    }
    this.apiService.postData('wishlist/add',data).subscribe((result)=>{
			if (result['status'] == 200) {
        this.productDetails.favorite = result['favorite'];
			}
		},(error)=>{
			console.log(error);
		})
  }

  addQty(id:any){
    this.quantity = parseInt(this.quantity)+parseInt('1');
  }

  removeQty(id:any){
    if(this.quantity !=1){
      this.quantity = parseInt(this.quantity)-parseInt('1');
    }else{
      this.quantity = 1;
    }
    
  }

  chooseContact(id:any,fname:any,lname:any){
    this.contactId =id;
	  this.defaultContact = fname+' '+lname;
    this.getEvents();
  }

  chooseEvent(id:any,name:any){
    this.eventId = id;
	  this.defaultEvent = name;
  }

  addToCart(){
    this.isCart = true;
    let data = {
      userId:this.userId,
      productId:this.productId,
      contactId : this.contactId,
      eventId : this.eventId,
      quantity : this.quantity
    }
    if(this.userId !='' && this.userId !=null){
      this.apiService.postData('add-cart',data).subscribe((result)=>{
        if (result['status'] == 200) {
          this.countCart = result['data'].total;
          this.modalService.dismissAll();
          this.toastrService.presentToast(result.message, 'success');
          this.events.publishSomeData({
            type: 'cart-total-count',
            countCart: this.countCart
          });
        }else{
          this.toastrService.presentToast(result.message, 'error');
        }
        this.isCart = false;
      },(error)=>{
        this.isCart = false;
        console.log(error);
      })
    }else{
      this.router.navigateByUrl('/signin')
    }
    
  }

  contactModal(cart: any,id:any){
    if(this.userId !='' && this.userId !=null){
      this.modalService.open(cart, { centered: true,size:'sm' } ).result.then((result) => {
        this.closeResult = `Closed with: ${result}`;
      }, (reason) => {
        this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
      });
    }else{
      this.router.navigateByUrl('/signin')
    }
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  handleProductImgError(ev: any) {
		const source = ev.srcElement;
		source.src = this.productDefaultImg;
	}

}
