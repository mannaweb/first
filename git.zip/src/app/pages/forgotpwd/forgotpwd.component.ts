import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ApiService } from '../../services/api.service';
import { ToastrService } from '../../services/toastr.service';

@Component({
  selector: 'app-forgotpwd',
  templateUrl: './forgotpwd.component.html',
  styleUrls: ['./forgotpwd.component.scss'],
	encapsulation:ViewEncapsulation.None
})
export class ForgotpwdComponent implements OnInit {
  passwordType: string = 'password';
	passwordTypeIclass: string = 'fas fa-fw fa-eye-slash';
  passwordType2: string = 'password';
	passwordTypeIclass2: string = 'fas fa-fw fa-eye-slash';
  email: any = '';
  isFpwd: any = false;
  otp: any = '';
  isOtp: any = false;
  userId: any = '';
  password: any = '';
  confirmPassword: any = '';
  isCpwd: any = false;
  stepNumber: any = 1;
  constructor(
    public router: Router,
    public route: ActivatedRoute,
    public apiService: ApiService,
    public toastrService: ToastrService
  ) { }

  ngOnInit(): void {
  }

  forgotPwd() {
    this.isFpwd = true;
    this.apiService.postData('send-forget-otp', {email: this.email}).subscribe( async (result) => {
      this.isFpwd = false;
      if (result['status'] == 200) {
        this.userId = result.data.userId;
        this.stepNumber = 2;
        await this.toastrService.presentToast(result.message, 'success');
      } else {
        this.toastrService.presentToast(result.message, 'error');
      }
    }, (error) => {
      this.isFpwd = false;
      console.log(error);
    })
  }

  submitOtp(){
    this.isOtp = true;
    this.apiService.postData('check-forget-otp', {userId: this.userId, otp: this.otp}).subscribe( async (result) => {
      this.isOtp = false;
      if (result['status'] == 200) {
        this.stepNumber = 3;
        await this.toastrService.presentToast(result.message, 'success');
      } else {
        this.toastrService.presentToast(result.message, 'error');
      }
    }, (error) => {
      this.isOtp = false;
      console.log(error);
    })
  }

  changePwd() {
    this.isCpwd = true;
    this.apiService.postData('change-forget-password', {userId: this.userId, newPassword:this.password, newConfirmPassword:this.confirmPassword}).subscribe( async (result) => {
      this.isCpwd = false;
      if (result['status'] == 200) {
        await this.toastrService.presentToast(result.message, 'success');
        this.router.navigateByUrl('/signin')
      } else {
        this.toastrService.presentToast(result.message, 'error');
      }
    }, (error) => {
      this.isCpwd = false;
      console.log(error);
    })
  }

  numberOnly(event:any): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;

  }

  changePasswordType() {
		if (this.passwordType == 'password') {
			this.passwordType = 'text';
			this.passwordTypeIclass = 'fas fa-fw fa-eye';
		} else {
			this.passwordType = 'password';
			this.passwordTypeIclass = 'fas fa-fw fa-eye-slash';
		}
	}

  changePasswordType2() {
		if (this.passwordType2 == 'password') {
			this.passwordType2 = 'text';
			this.passwordTypeIclass2 = 'fas fa-fw fa-eye';
		} else {
			this.passwordType2 = 'password';
			this.passwordTypeIclass2 = 'fas fa-fw fa-eye-slash';
		}
	}

}
