import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { ForgotpwdRoutingModule } from './forgotpwd-routing.module';
import { ForgotpwdComponent } from './forgotpwd.component';
import { FormsModule } from '@angular/forms';


@NgModule({
  declarations: [
    ForgotpwdComponent
  ],
  imports: [
    CommonModule,
    ForgotpwdRoutingModule,
		RouterModule,
		NgbModule,
    FormsModule
  ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})
export class ForgotpwdModule { }
