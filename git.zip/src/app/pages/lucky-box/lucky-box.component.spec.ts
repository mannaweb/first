import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LuckyBoxComponent } from './lucky-box.component';

describe('LuckyBoxComponent', () => {
  let component: LuckyBoxComponent;
  let fixture: ComponentFixture<LuckyBoxComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LuckyBoxComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LuckyBoxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
