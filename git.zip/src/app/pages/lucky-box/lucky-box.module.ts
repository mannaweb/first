import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { LuckyBoxRoutingModule } from './lucky-box-routing.module';
import { LuckyBoxComponent } from './lucky-box.component';
import { ProductLoaderModule } from '../../component/product-loader/product-loader.module';
import { GiftingActivityLoaderModule } from '../../component/gifting-activity-loader/gifting-activity-loader.module';

@NgModule({
  declarations: [
    LuckyBoxComponent
  ],
  imports: [
    CommonModule,
    LuckyBoxRoutingModule,
    NgbModule,
    ProductLoaderModule,
    GiftingActivityLoaderModule
  ]
})
export class LuckyBoxModule { }
