import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { ProductRoutingModule } from './product-routing.module';
import { ProductComponent } from './product.component';
import { ProductLoaderModule } from '../../component/product-loader/product-loader.module';
import { GiftingActivityLoaderModule } from '../../component/gifting-activity-loader/gifting-activity-loader.module';

@NgModule({
  declarations: [
    ProductComponent
  ],
  imports: [
    CommonModule,
    ProductRoutingModule,
    NgbModule,
    ProductLoaderModule,
    GiftingActivityLoaderModule
  ]
})
export class ProductModule { }
