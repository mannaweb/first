import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import {NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { Router, ActivatedRoute } from '@angular/router';
import { ApiService } from '../../services/api.service';
import { ToastrService } from '../../services/toastr.service';
import { environment } from '../../../environments/environment';
import { EventsService } from '../../services/events.service';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ProductComponent implements OnInit {
  userId=localStorage.getItem('user_id');
  productDefaultImg:any = environment.productDefaultImg;
  productList: any = [];
  limit = 12;
  lastId: any = '';
  is_data: any = 2;
  relationShiplist:any = [];
  genderlist:any = [];
  selectRelations:any = 'Select Relationship';
  selectRelationsId:any = '';
  selectgender:any = 'Select Gender';
  selectgenderId:any = '';
  productDetails: any = [];
  productImage:any = 'assets/img/load-loading.gif';
  closeResult = '';
  isCart:any = false;
  productId:any = '';
  contactId:any = '';
  countCart:any= 0;
  defaultContact:any = 'Select Contact';
  contactsList:any = [];
  productName:any = '';
  quantity:any = 1;
  defaultEvent:any = 'Select Event';
  eventList:any = [];
  eventId:any='';
  isProssing:any = false;
  ishidden:any = 2;
  giftingActivityList:any = [];
  is_activity_data:any = 2;
  bannerList:any = [];
  activated:any = '';
  constructor(
    private modalService: NgbModal,
    public router:Router, 
    public route: ActivatedRoute,
    public apiService: ApiService,
    public toastrService: ToastrService,
    private events: EventsService
  ) { }

  ngOnInit(): void {
     this.getBanners();
     this.getProducts();
     this.getRelationShiplist();
     this.getGenderlist();
     this.getContacts();
     this.giftingActivity();
  }

  openVerticallyCentered(content: any,id:any,name:any) {
    this.productImage = 'assets/img/load-loading.gif';
    this.productName = name;
    this.productId = id;
    this.modalService.open(content, { centered: true } ).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
    let data={
      productId:id
    }
    this.apiService.postData('product/details',data).subscribe((result)=>{
      if (result['status'] == 200) {
        this.productDetails = result['data'].ProductDetails;
        this.productImage = result['data'].ProductImages[0].image;
      } 
    },(error)=>{
      console.log(error);
    })
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  getBanners(){
    this.apiService.postData('pages',{slug:'products'}).subscribe((result)=>{
			if (result['status'] == 200) {
        this.bannerList = result['data'].banner_details;
			} 
		},(error)=>{
			console.log(error);
		})
  }

  getProducts(){
    this.is_data = 2;
    let data={
      userId:this.userId,
      limit:this.limit,
      lastId:this.lastId,
      relationship_id:this.selectRelationsId
    }
    this.apiService.postData('product/list',data).subscribe((result)=>{
			if (result['status'] == 200) {
        this.productList = result['data'];
        if (this.productList.length > 0 ){                    
          this.lastId = this.productList[this.productList.length - 1].id;
        }        
			} 
      if(result['count'] < 12){
        this.ishidden = 1;
      }
      this.is_data = 1;     
		},(error)=>{
			console.log(error);
		})
  }

  loadmore(){
    this.isProssing = true;
    let data={
      userId:this.userId,
      limit:this.limit,
      lastId:this.lastId,
      relationship_id:this.selectRelationsId
    }
    this.apiService.postData('product/list',data).subscribe((result)=>{
			if (result['status'] == 200) {
          this.isProssing = false;
          if(result['data'].length < 12){                    
            this.ishidden = 1;
          }
          this.productList.push(...result['data']);
        if (this.productList.length > 0){                    
          this.lastId = this.productList[this.productList.length - 1].id;
        }        
			}
		},(error)=>{
			console.log(error);
		})
  }

  getRelationShiplist(){
    this.apiService.postData('relationships-list',{user_id:this.userId}).subscribe((result)=>{
			if (result['status'] == 200) {
        this.relationShiplist = result['data'];
			}     
		},(error)=>{
			console.log(error);
		})
  }

  getGenderlist(){
    this.apiService.postData('gender/list',{}).subscribe((result)=>{
			if (result['status'] == 200) {
        this.genderlist = result['data'];
			}     
		},(error)=>{
			console.log(error);
		})
  }

  selectRelationship(id:any,name:any){
    this.selectRelationsId=id;
	  this.selectRelations = name;
  }

  selectGender(id:any,name:any){
    this.selectgenderId=id;
	  this.selectgender = name;
  }

  manageFavourite(product_id:any){
    let data={
      userId:this.userId,
      product_id:product_id
    }
    this.apiService.postData('wishlist/add',data).subscribe((result)=>{
			if (result['status'] == 200) {
        this.productDetails.favorite = result['favorite'];
			}else{
        this.toastrService.presentToast(result.message, 'error');
      }
		},(error)=>{
			console.log(error);
		})
  }

  manageLikeDislike(product_id:any,type_status:any){
    let data={
      userId:this.userId,
      productId:product_id,
      typeStatus : type_status
    }
    this.apiService.postData('add-like',data).subscribe((result)=>{
			if (result['status'] == 200) {
        this.productDetails.favorite = result['favorite'];
			}else{
        this.toastrService.presentToast(result.message, 'error');
      }
		},(error)=>{
			console.log(error);
		})
  }

  handleProductImgError(ev: any) {
		const source = ev.srcElement;
		source.src = this.productDefaultImg;
	}

  contactModal(cart: any,id:any,name:any){
    this.productImage = 'assets/img/load-loading.gif';
    if(this.userId !='' && this.userId !=null){
      this.productName = name;
      this.productId = id;
      this.modalService.open(cart, { centered: true ,size:'sm'} ).result.then((result) => {
        this.closeResult = `Closed with: ${result}`;
      }, (reason) => {
        this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
      });
    }else{
      this.router.navigateByUrl('/signin')
    }
  }

  addToCart(){
    this.isCart = true;
    let data = {
      userId:this.userId,
      productId:this.productId,
      contactId : this.contactId,
      eventId : this.eventId,
      quantity : this.quantity
    }
    if(this.userId !='' && this.userId !=null){
      this.apiService.postData('add-cart',data).subscribe((result)=>{
        if (result['status'] == 200) { 
          this.countCart = result['data'].total;
          this.modalService.dismissAll();
          this.toastrService.presentToast(result.message, 'success');
          this.events.publishSomeData({
            type: 'cart-total-count',
            countCart: this.countCart
          });
        }else{
          this.toastrService.presentToast(result.message, 'error');
        }
        this.isCart = false;
      },(error)=>{
        this.isCart = false;
        console.log(error);
      })
    }else{
      this.router.navigateByUrl('/signin')
    }
    
  }

  chooseContact(id:any,fname:any,lname:any){
    this.contactId = id;
	  this.defaultContact = fname+' '+lname;
    this.getEvents();
  }

  getEvents(){
    let data={
      contactId:this.contactId
    }
    this.apiService.postData('contact-wise-events',data).subscribe((result)=>{
			if (result['status'] == 200) {
        this.eventList = result['data'];
			}  
		},(error)=>{
			console.log(error);
		})
  }
  

  getContacts(){
    let data={
      userId:this.userId,
      limit: 30,
      start : '',
      orderBy: 'id',
      order : 'DESC'
    }
    this.apiService.postData('contacts/list',data).subscribe((result)=>{
			if(result['status'] == 200) {
        this.contactsList = result['data'];
			}  
		},(error)=>{
			console.log(error);
		})
  }

  
  chooseEvent(id:any,name:any){
    this.eventId = id;
	  this.defaultEvent = name;
  }

  giftingActivity(){
    this.is_activity_data = 2;
    let data={
      userId:this.userId,
      limit:5,
    }
    this.apiService.postData('gifting-activity',data).subscribe((result)=>{
			if (result['status'] == 200) {
        this.giftingActivityList = result['data'];
			}  
      this.is_activity_data = 1; 
		},(error)=>{
			console.log(error);
		})
  }
  


}
