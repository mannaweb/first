import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {ApiService} from '../../services/api.service';

@Component({
  selector: 'app-privacy',
  templateUrl: './privacy.component.html',
  styleUrls: ['./privacy.component.scss'],
	encapsulation:ViewEncapsulation.None
})
export class PrivacyComponent implements OnInit {
  pageData:any = [];
  is_data:any = 2;
  constructor(
    public router:Router,
    public route: ActivatedRoute,
    public apiService:ApiService
  ) { }

  ngOnInit(): void {    
    this.apiService.postData('pages',{slug:'policy'}).subscribe((result)=>{
      this.pageData = result['data'];
      this.is_data = 1
		},(error)=>{;
			console.log(error);
		})
  }

}
