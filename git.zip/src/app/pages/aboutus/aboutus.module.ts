import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule } from '@angular/forms';
import { AboutusRoutingModule } from './aboutus-routing.module';
import { AboutusComponent } from './aboutus.component';
import { AboutLoaderModule } from '../../component/about-loader/about-loader.module';
import { SpecialityLoaderModule } from '../../component/speciality-loader/speciality-loader.module';


@NgModule({
  declarations: [
    AboutusComponent
  ],
  imports: [
    CommonModule,
    RouterModule,
    AboutusRoutingModule,
    NgbModule,
    FormsModule,
    AboutLoaderModule,
    SpecialityLoaderModule
  ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})
export class AboutusModule { }
