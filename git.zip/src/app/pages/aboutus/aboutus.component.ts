import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {ApiService} from '../../services/api.service';
import {environment} from '../../../environments/environment';
import { ToastrService } from '../../services/toastr.service';

@Component({
  selector: 'app-aboutus',
  templateUrl: './aboutus.component.html',
  styleUrls: ['./aboutus.component.scss'],
	encapsulation:ViewEncapsulation.None
})
export class AboutusComponent implements OnInit {
  pageData:any = [];
  is_data:any = 2;
  is_feature:any = 2;
  is_contact:any = 2;
  giftImage:any=environment.giftImage;
  contactImage:any=environment.contactImage;
  specialityData:any = [];
  settingsData:any = [];
  isContactUs: any = false;
  contactData:any={'name':'','email':'','message':''};
  constructor(
    public router:Router,
    public route: ActivatedRoute,
    public apiService:ApiService,
    public toastrService: ToastrService,
  ) { }

  ngOnInit(): void {
    this.getPage();
    this.getSpeciality();
    this.getSettings();
  }

  getPage(){
    this.apiService.postData('pages',{slug:'aboutus'}).subscribe((result)=>{
      this.pageData = result['data'];
      this.is_data = 1
		},(error)=>{;
			console.log(error);
		})
  }

  getSpeciality(){
    this.apiService.postData('speciality',{}).subscribe((result)=>{
      this.specialityData = result['data'];
      this.is_feature = 1
		},(error)=>{;
			console.log(error);
		})
  }

  getSettings(){
    this.apiService.postData('settings',{id:1}).subscribe((result)=>{
      if (result['status'] == 200) {
        this.settingsData = result['data'];
      }
      this.is_contact = 1;
    },(error)=>{
      console.log(error);
    })
  }

  openLink(link:any){
    window.open(link, '_blank');
  }

  contactUs() {
    this.isContactUs = true;
    this.apiService.postData('send-contact-form', this.contactData).subscribe( async (result) => {
      this.isContactUs = false;
      if (result['status'] == 200) {
        await this.toastrService.presentToast(result.message, 'success');
				this.contactData = {'name':'','email':'','message':''};
      } else {
        this.toastrService.presentToast(result.message, 'error');
      }
    }, (error) => {
      this.isContactUs = false;
      console.log(error);
    })
  }

  handleGiftImgError(ev: any){
		let source = ev.srcElement;
		source.src = this.giftImage;
	}

  handleContactImgError(ev: any){
		let source = ev.srcElement;
		source.src = this.contactImage;
	}

}
