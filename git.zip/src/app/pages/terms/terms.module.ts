import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';


import { TermsRoutingModule } from './terms-routing.module';
import { TermsComponent } from './terms.component';
import { TermsLoaderModule } from '../../component/terms-loader/terms-loader.module';


@NgModule({
  declarations: [
    TermsComponent
  ],
  imports: [
    CommonModule,
    RouterModule,
    TermsRoutingModule,
    NgbModule,
    TermsLoaderModule
  ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})
export class TermsModule { }
