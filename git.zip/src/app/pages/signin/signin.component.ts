import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ApiService } from '../../services/api.service';
import { EventsService } from '../../services/events.service';
import { ToastrService } from '../../services/toastr.service';
import { SocialAuthService } from "angularx-social-login";
import { FacebookLoginProvider, GoogleLoginProvider } from "angularx-social-login";

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.scss'],
	encapsulation:ViewEncapsulation.None
})
export class SigninComponent implements OnInit {
  passwordType: string = 'password';
	passwordTypeIclass: string = 'fas fa-fw fa-eye-slash';
  signinData: any = { 'email': '', 'password': '', 'token': '' };
  returnUrl: string = '';
  isSignIn: any = false;
  constructor(
    public router: Router,
    public route: ActivatedRoute,
    public apiService: ApiService,
    public toastrService: ToastrService,
    private events: EventsService,
    private authService: SocialAuthService
  ) { }

  ngOnInit(): void {
    this.returnUrl = this.route.snapshot.queryParams.returnUrl || 'user/account';
  }

  signIn() {
    this.isSignIn = true;
    this.apiService.postData('login', this.signinData).subscribe(async (result) => {
      this.isSignIn = false;
      if (result['status'] == 200) {
        await this.toastrService.presentToast(result.message, 'success');
        localStorage.setItem('user_id', result['data'].user_id);
        localStorage.setItem('user_role', result['data'].role);
        this.events.publishSomeData({
          type: 'login',
          userId: result['data'].user_id
        });
        this.router.navigateByUrl(this.returnUrl)
      } else {
        this.toastrService.presentToast(result.message, 'error');
      }
    }, (error) => {
      this.isSignIn = false;
      console.log(error);
    })
  }

  changePasswordType() {
		if (this.passwordType == 'password') {
			this.passwordType = 'text';
			this.passwordTypeIclass = 'fas fa-fw fa-eye';
		} else {
			this.passwordType = 'password';
			this.passwordTypeIclass = 'fas fa-fw fa-eye-slash';
		}
	}

  signInWithGoogle(): void {
    this.authService.signIn(GoogleLoginProvider.PROVIDER_ID).then(user => {
      this.apiService.postData('socal-login', user).subscribe( async (result) => {
        this.isSignIn = false;
        if (result['status'] == 200) {
          await this.toastrService.presentToast(result.message, 'success');
          localStorage.setItem('user_id', result['data'].user_id);
          localStorage.setItem('user_api_Key', result['data'].user_api_Key);
          this.events.publishSomeData({
            type: 'login',
            userId: result['data'].user_id
          });
          this.router.navigateByUrl(this.returnUrl)
        } else {
          this.toastrService.presentToast(result.message, 'error');
        }
      }, (error) => {
        this.isSignIn = false;
        console.log(error);
      })
  })
  }

  signInWithFB(): void {
    this.authService.signIn(FacebookLoginProvider.PROVIDER_ID).then(user => {
        this.apiService.postData('socal-login', user).subscribe( async (result) => {
          this.isSignIn = false;
          if (result['status'] == 200) {
            await this.toastrService.presentToast(result.message, 'success');
            localStorage.setItem('user_id', result['data'].user_id);
            localStorage.setItem('user_api_Key', result['data'].user_api_Key);
            this.events.publishSomeData({
              type: 'login',
              userId: result['data'].user_id
            });
            this.router.navigateByUrl(this.returnUrl)
          } else {
            this.toastrService.presentToast(result.message, 'error');
          }
        }, (error) => {
          this.isSignIn = false;
          console.log(error);
        })
    })
  }

  signOut(): void {
    this.authService.signOut();
  }

}
