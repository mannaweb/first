import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ApiService } from '../../services/api.service';
import { ToastrService } from '../../services/toastr.service';
import { SocialAuthService } from "angularx-social-login";
import { FacebookLoginProvider, GoogleLoginProvider } from "angularx-social-login";
import { EventsService } from '../../services/events.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss'],
	encapsulation:ViewEncapsulation.None
})
export class SignupComponent implements OnInit {
  passwordType: string = 'password';
	passwordTypeIclass: string = 'fas fa-fw fa-eye-slash';
  signupData: any = { 'name': '', 'email': '', 'password': ''};
  isSignUp: any = false;
  forSignup: any = 1;
  otp: any;
  isOtp: any = false;
  user_id: any;
  returnUrl: string = '';
  constructor(
    public router: Router,
    public route: ActivatedRoute,
    public apiService: ApiService,
    public toastrService: ToastrService,
    private events: EventsService,
    private authService: SocialAuthService
  ) { }

  ngOnInit(): void {
    this.returnUrl = this.route.snapshot.queryParams.returnUrl || 'user/account';
  }

  signUp() {
    this.isSignUp = true;
    this.apiService.postData('signup', this.signupData).subscribe( async (result) => {
      this.isSignUp = false;
      if (result['status'] == 200) {
        this.user_id = result.data.user_id;
        this.forSignup = 2;
        await this.toastrService.presentToast(result.message, 'success');
      } else {
        this.toastrService.presentToast(result.message, 'error');
      }
    }, (error) => {
      this.isSignUp = false;
      console.log(error);
    })
  }

  submitOtp(){
    this.isOtp = true;
    this.apiService.postData('checksignupotp', {user_id: this.user_id, otp: this.otp}).subscribe( async (result) => {
      this.isOtp = false;
      if (result['status'] == 200) {
        await this.toastrService.presentToast(result.message, 'success');
        this.router.navigateByUrl('/signin')
      } else {
        this.toastrService.presentToast(result.message, 'error');
      }
    }, (error) => {
      this.isOtp = false;
      console.log(error);
    })
  }

  numberOnly(event:any): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;

  }

  changePasswordType() {
		if (this.passwordType == 'password') {
			this.passwordType = 'text';
			this.passwordTypeIclass = 'fas fa-fw fa-eye';
		} else {
			this.passwordType = 'password';
			this.passwordTypeIclass = 'fas fa-fw fa-eye-slash';
		}
	}

  signInWithGoogle(): void {
    this.authService.signIn(GoogleLoginProvider.PROVIDER_ID).then(user => {
      this.apiService.postData('socal-login', user).subscribe( async (result) => {
        this.isSignUp = false;
        if (result['status'] == 200) {
          await this.toastrService.presentToast(result.message, 'success');
          localStorage.setItem('user_id', result['data'].user_id);
          localStorage.setItem('user_api_Key', result['data'].user_api_Key);
          this.events.publishSomeData({
            type: 'login',
            userId: result['data'].user_id
          });
          this.router.navigateByUrl(this.returnUrl)
        } else {
          this.toastrService.presentToast(result.message, 'error');
        }
      }, (error) => {
        this.isSignUp = false;
        console.log(error);
      })
  })
  }

  signInWithFB(): void {
    this.authService.signIn(FacebookLoginProvider.PROVIDER_ID).then(user => {
        this.apiService.postData('socal-login', user).subscribe( async (result) => {
          this.isSignUp = false;
          if (result['status'] == 200) {
            await this.toastrService.presentToast(result.message, 'success');
            localStorage.setItem('user_id', result['data'].user_id);
            localStorage.setItem('user_api_Key', result['data'].user_api_Key);
            this.events.publishSomeData({
              type: 'login',
              userId: result['data'].user_id
            });
            this.router.navigateByUrl(this.returnUrl)
          } else {
            this.toastrService.presentToast(result.message, 'error');
          }
        }, (error) => {
          this.isSignUp = false;
          console.log(error);
        })
    })
  }

  signOut(): void {
    this.authService.signOut();
  }

}
