import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { CheckoutRoutingModule } from './checkout-routing.module';
import { CheckoutComponent } from './checkout.component';
import { CheckoutLoaderModule } from '../../component/checkout-loader/checkout-loader.module';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    CheckoutComponent
  ],
  imports: [
    CommonModule,
    RouterModule,
    CheckoutRoutingModule,
    NgbModule,
    CheckoutLoaderModule,
    FormsModule
  ]
})
export class CheckoutModule { }
