import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { Router, ActivatedRoute } from '@angular/router';
import { ApiService } from '../../services/api.service';
import { ToastrService } from '../../services/toastr.service';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.scss'],
	encapsulation:ViewEncapsulation.None
})
export class CheckoutComponent implements OnInit {
  closeResult = '';
  productDefaultImg:any = environment.productDefaultImg;
  userId=localStorage.getItem('user_id');
  cartList:any = [];
  productPrice:any = [];
  is_data:any = 2;
  paymentMethod: any = 'stripe'
  termsofcondition: any;
  isContinue: any = false;
  constructor(
    private modalService: NgbModal,
    public router:Router, 
    public route: ActivatedRoute,
    public apiService: ApiService,
    public toastrService: ToastrService
    ) { }

  ngOnInit(): void {
    this.getCheckout();
  }

  getCheckout(){
    let data={
      userId:this.userId,
      cartId :"",
      orderBy:"",
      order:""
    }
    this.apiService.postData('cart',data).subscribe((result)=>{
      if (result['status'] == 200) {
        this.cartList = result['data'].cart_details;
        this.productPrice = result['data'].pricing_details;
      }
      this.is_data = 1;     
    },(error)=>{
      console.log(error);
    })
  }


  placeOrder(){
    this.isContinue = true;
    const data = {
      userId: this.userId,
      paymentMethod: this.paymentMethod,
      termsofcondition: this.termsofcondition
    }
    this.apiService.postData('payment', data).subscribe((result) => {
      this.isContinue = false;
      if(result.status == 200){
        window.location.href = result.data.transaction_url;
      } else {
        this.toastrService.presentToast(result.message, 'error');
      }
    }, (error) => {
      this.isContinue = false;
      console.log(error);
    })
  }

  handleProductImgError(ev: any) {
		const source = ev.srcElement;
		source.src = this.productDefaultImg;
	}

  openVerticallyCentered(content: any) {
    this.modalService.open(content, { centered: true } ).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }
}
