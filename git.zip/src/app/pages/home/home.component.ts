import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { ApiService } from '../../services/api.service';
import { ToastrService } from '../../services/toastr.service';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
	encapsulation:ViewEncapsulation.None
})
export class HomeComponent implements OnInit {
  userDefaultImg: any = environment.userDefaultImg;
  productDefaultImg:any = environment.productDefaultImg;
  relationshipList: any = [];
  constructor(
    public apiService: ApiService,
    public toastrService: ToastrService
  ) { }

  ngOnInit(): void {
    //this.getRelationShiplist();
  }

  // getRelationShiplist(){
  //   let data={
  //     limit: "4",
  //     orderBy:'id',
  //     order: "DESC",
  //     start: ""
  //   }
  //   this.apiService.postData('order/list',data).subscribe((result)=>{
  //     this.relationshipList = result['data'];      
	// 	},(error)=>{
	// 		console.log(error);
	// 	})
  // }



}
