import { Component, OnInit, ViewEncapsulation,ElementRef, ViewChild } from '@angular/core';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { Router, ActivatedRoute } from '@angular/router';
import { ApiService } from '../../services/api.service';
import { ToastrService } from '../../services/toastr.service';
import { environment } from '../../../environments/environment';
import { EventsService } from '../../services/events.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.scss'],
	encapsulation:ViewEncapsulation.None
})
export class CartComponent implements OnInit {
  //@ViewChild('myDOMElement', { static: true }) MyDOMElement: ElementRef;
  productDefaultImg:any = environment.productDefaultImg;
  userId=localStorage.getItem('user_id');
  cartList:any = [];
  is_data:any = 2;
  closeResult = '';
  quantity:any = [];
  defaultAddress:any = [];
  defaultAddressValue:any = [];
  shippingAddress:any = '';
  city:any = '';
  state:any = '';
  pincode:any = '';
  productPrice:any = [];
  shippingFlag:any = 1;
  contactId:any = '';
  cartId:any = '';
  countCart:any = '0';
  constructor(
    private modalService: NgbModal,
    public router:Router, 
    public route: ActivatedRoute,
    public apiService: ApiService,
    public toastrService: ToastrService,
    private events: EventsService
    ) { }

  ngOnInit(): void {
    this.getCart();
  }

  getCart(){
    if(this.userId !='' && this.userId !=null){
      let data={
        userId:this.userId,
        cartId :"",
        orderBy:"",
        order:""
      }
      this.apiService.postData('cart',data).subscribe((result)=>{
        if (result['status'] == 200) {
          this.cartList = result['data'].cart_details;
          this.productPrice = result['data'].pricing_details;
          for (var _i = 0; _i < this.cartList.length; _i++) {
            var details = this.cartList[_i].details;
            for (var j = 0; j < details.length; j++) {
                var id =  details[j].cart_id
                this.quantity[id] = details[j].quantity;
                if(details[j].shipping_address_flag == 1){
                  this.defaultAddress[id] = "My Address";
                  this.defaultAddressValue[id] = details[j].address_1;
                }else if(details[j].shipping_address_flag == 2){
                  this.defaultAddress[id] = "Recipient's Address";
                  this.defaultAddressValue[id] = details[j].address_1;
                }else{
                  this.defaultAddress[id] = 'Shipping Address';
                  this.defaultAddressValue[id] = '';
                }
                
            }
          }
          this.is_data = 1;  
        }else if (result['status'] == 400){
          this.cartList = [];
          this.is_data = 3; 
        }           
      },(error)=>{
        console.log(error);
      })
    }else{
      this.router.navigateByUrl('/signin')
    }
    
  }

  addQty(id:any){
    var qty = parseInt(this.quantity[id])+parseInt('1');    
    this.apiService.postData('update-cart-quantity',{"cartId": id,quantity:qty}).subscribe((result)=>{
      if (result['status'] == 200) {
        this.quantity[id] = qty;
        this.getCart();
      }    
    },(error)=>{
      console.log(error);
    })
  }

  removeQty(id:any){
    if(this.quantity[id] !=1){
      var qty = parseInt(this.quantity[id])-parseInt('1');
    }else{
      var qty = 1;
    }      
    this.apiService.postData('update-cart-quantity',{"cartId": id,quantity:qty}).subscribe((result)=>{
      if (result['status'] == 200) {
        this.quantity[id] = qty;          
        this.getCart();
      }    
    },(error)=>{
      console.log(error);
    })
  }

  chooseAddress(type:any,cart_id:any,contact_id:any){
    this.apiService.postData('update-cart-shipping-flag',{"cartId": cart_id,shippingAddressFlag:type}).subscribe((result)=>{
      if (result['status'] == 200) {
         
      }    
    },(error)=>{
      console.log(error);
    })
    if(type == 1){
      this.defaultAddress[cart_id] = "My Address";
      this.apiService.postData('user/details',{"userId": this.userId}).subscribe((result)=>{
        if (result['status'] == 200) {
          this.defaultAddressValue[cart_id] = result['data'].userdetails.billing_address_1;
        }    
      },(error)=>{
        console.log(error);
      })
    }else if(type == 2){
      this.defaultAddress[cart_id] = "Recipient's Address";
      this.apiService.postData('contacts/contact-address',{"contactId": contact_id}).subscribe((result)=>{
        if (result['status'] == 200) {
          this.defaultAddressValue[cart_id] = result['data'].address_1;
        }    
      },(error)=>{
        console.log(error);
      })
    }
    
  }

  removeCart(id:any){
    this.apiService.postData('delete-cart',{"userId": this.userId,"cartId": id}).subscribe((result)=>{
			if (result['status'] == 200) {
        this.countCart = result['data'].total;
        this.events.publishSomeData({
          type: 'cart-total-count',
          countCart: this.countCart
        });
        this.getCart();
			} 
      this.is_data = 1;     
		},(error)=>{
			console.log(error);
		})
  }

  handleProductImgError(ev: any) {
		const source = ev.srcElement;
		source.src = this.productDefaultImg;
	}


  openVerticallyCentered(content: any,cart_id:any,contact_id:any,type:any) {    
    this.modalService.open(content, { centered: true } ).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
    if(content == 'address'){
      if(type == 1){
        this.apiService.postData('user/details',{"userId": this.userId}).subscribe((result)=>{
          if (result['status'] == 200) {
            this.shippingAddress = result['data'].userdetails.billing_address_1;
            this.city = result['data'].userdetails.city;
            this.state = result['data'].userdetails.state;
            this.pincode = result['data'].userdetails.pincode;
          }    
        },(error)=>{
          console.log(error);
        })
      }else if(type == 2){
        this.apiService.postData('contacts/contact-address',{"contactId": contact_id}).subscribe((result)=>{
          if (result['status'] == 200) {
            this.defaultAddressValue[cart_id] = result['data'].address_1;
            this.shippingAddress = result['data'].address_1;
            this.city = result['data'].city;
            this.state = result['data'].state;
            this.pincode = result['data'].pincode;
          }    
        },(error)=>{
          console.log(error);
        })
      }
    }
  }

  openShippingAddress(content: any,cart_id:any,contact_id:any,type:any) {
      this.shippingFlag = type;
      this.cartId = cart_id;
      if(type == 1){
        this.contactId = this.userId;
        this.apiService.postData('user/details',{"userId": this.userId}).subscribe((result)=>{
          if (result['status'] == 200) {
            this.shippingAddress = result['data'].userdetails.billing_address_1;
            this.city = result['data'].userdetails.city;
            this.pincode = result['data'].userdetails.pincode;
          }    
        },(error)=>{
          console.log(error);
        })
      }else if(type == 2){
        this.contactId = contact_id;
        this.apiService.postData('contacts/contact-address',{"contactId": contact_id}).subscribe((result)=>{
          if (result['status'] == 200) {
            this.defaultAddressValue[cart_id] = result['data'].address_1;
            this.shippingAddress = result['data'].address_1;
            this.city = result['data'].city;
            this.pincode = result['data'].zipcode;
          }    
        },(error)=>{
          console.log(error);
        })
      }
    this.modalService.open(content, { centered: true } ).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  updateAddress(){
    let data= {
      "shippingFlag": this.shippingFlag,
      'updateId':this.contactId,
      'address':this.shippingAddress,
      'city':this.city,
      'state': this.state,
      'zipcode':this.pincode,
    }
    this.apiService.postData('cart-shipping-address-update',data).subscribe((result)=>{
      if (result['status'] == 200) {
        this.defaultAddressValue[this.cartId] = this.shippingAddress;
      } else{
        this.toastrService.presentToast(result.message, 'error');
      }   
    },(error)=>{
      console.log(error);
    })
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }
}