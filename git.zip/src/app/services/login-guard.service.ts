import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class LoginGuardService implements CanActivate {

  constructor(
    private router: Router
  ) { }

  public canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {

    const authInfo = {
      authenticated: (
        localStorage.getItem('user_id') !== 'undefined' &&
        localStorage.getItem('user_id') !== '' &&
        localStorage.getItem('user_id') !== null)?
        true:
        false
    };

    if (authInfo.authenticated) {
      this.router.navigate(['user/profile']);
    }
    return true;
  }
}
