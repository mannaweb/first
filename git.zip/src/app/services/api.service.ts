import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of, throwError} from 'rxjs';
import { map, catchError, mapTo, tap,share } from "rxjs/operators";
import { environment } from '../../environments/environment';

@Injectable({
	providedIn: 'root'
})
export class ApiService {

	constructor(private http: HttpClient) { }

	getDataP(url: any) {
		return new Promise((resolve, reject) => {
			this.http.get(environment.apiurl+url)
			.subscribe(
				res => {
					resolve(res);
				},
				err => {
					reject(err);
				}
				);
		});
	}

	postDataP(url: any,data: any) {
		return new Promise((resolve, reject) => {
			this.http.post(environment.apiurl+url,data)
			.subscribe(
				res => {
					resolve(res);
				},
				err => {
					reject(err);
				}
				);
		});
	}

	getData(url: any):Observable<any>{
		return this.http.get(environment.apiurl+url).pipe(
			tap(res => res),
			catchError(this.handleError())
		);
	}

	postData(url: any,data: any,header: any = []):Observable<any>{

		let headers = new HttpHeaders().set('Content-Type', 'application/json');
		if(header.length > 0){
			for(var index = 0; index < header.length; index++){
				const element = header[index];
				headers = headers.set(element.field, element.value);
			}
		}
		return this.http.post(environment.apiurl+url,data,{ headers: headers }).pipe(
			tap(res => res),
			catchError(this.handleError())
		);
	}

	private handleError<T> (operation = 'operation', result?: T) {
		return (error: any): Observable<T> => {
			// console.error(error);
			return of(result as T);
		};
	}

}
