import { Injectable } from '@angular/core';
import { ToastrService as toastr } from 'ngx-toastr';

@Injectable({
  providedIn: 'root'
})
export class ToastrService {
  toast: any = null;
  constructor(
    private toastr: toastr
  ) { }

  async presentToast(text: string, type: string) {
    const toastData = {
      timeOut: 3000,
      positionClass: 'toast-bottom-right',
      progressBar: true,
      maxOpened: 1,
      autoDismiss: true,
      newestOnTop: true,
      preventDuplicates: true
    };

    await this.showToast(type, text, toastData);
    return this.toast;
  }

  async presentClosableToast(text: string, type: string) {
    const toastData = {
      timeOut: 3000,
      positionClass: 'toast-bottom-right',
      closeButton: true,
      progressBar: true
    };

    await this.showToast(type, text, toastData);
    return this.toast;
  }

  async showToast(type: string, text: string, data: any) {
    if(type == 'success'){
      this.toast = await this.toastr.success(text, 'Success', data);
    } else if(type == 'error'){
      this.toast = await this.toastr.error(text, 'Error', data);
    } else if(type == 'failed'){
      this.toast = await this.toastr.info(text, 'Failed', data);
    }
  }
}
