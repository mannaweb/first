import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-history-loader',
  templateUrl: './history-loader.component.html',
  styleUrls: ['./history-loader.component.scss'],
	encapsulation:ViewEncapsulation.None
})
export class HistoryLoaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
