import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HistoryLoaderComponent } from './history-loader.component';



@NgModule({
  declarations: [
    HistoryLoaderComponent
  ],
  imports: [
    CommonModule
  ],
  exports: [
    HistoryLoaderComponent
  ]
})
export class HistoryLoaderModule { }
