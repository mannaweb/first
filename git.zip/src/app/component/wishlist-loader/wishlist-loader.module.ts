import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WishlistLoaderComponent } from './wishlist-loader.component';



@NgModule({
  declarations: [
    WishlistLoaderComponent
  ],
  imports: [
    CommonModule
  ],
  exports:[
    WishlistLoaderComponent
  ]
})
export class WishlistLoaderModule { }
