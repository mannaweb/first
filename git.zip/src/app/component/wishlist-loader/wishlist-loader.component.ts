import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-wishlist-loader',
  templateUrl: './wishlist-loader.component.html',
  styleUrls: ['./wishlist-loader.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class WishlistLoaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
