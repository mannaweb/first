import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WishlistLoaderComponent } from './wishlist-loader.component';

describe('WishlistLoaderComponent', () => {
  let component: WishlistLoaderComponent;
  let fixture: ComponentFixture<WishlistLoaderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WishlistLoaderComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WishlistLoaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
