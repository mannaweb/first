import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProductDetailsLoaderComponent } from './product-details-loader.component';



@NgModule({
  declarations: [
    ProductDetailsLoaderComponent
  ],
  imports: [
    CommonModule
  ],
  exports: [
    ProductDetailsLoaderComponent
  ]
})
export class ProductDetailsLoaderModule { }
