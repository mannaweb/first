import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-product-details-loader',
  templateUrl: './product-details-loader.component.html',
  styleUrls: ['./product-details-loader.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ProductDetailsLoaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
