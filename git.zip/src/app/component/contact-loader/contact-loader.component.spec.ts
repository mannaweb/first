import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ContactLoaderComponent } from './contact-loader.component';

describe('ContactLoaderComponent', () => {
  let component: ContactLoaderComponent;
  let fixture: ComponentFixture<ContactLoaderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ContactLoaderComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ContactLoaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
