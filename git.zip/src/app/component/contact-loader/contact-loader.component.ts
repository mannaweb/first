import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-contact-loader',
  templateUrl: './contact-loader.component.html',
  styleUrls: ['./contact-loader.component.scss'],
	encapsulation:ViewEncapsulation.None
})
export class ContactLoaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
