import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ContactLoaderComponent } from './contact-loader.component';



@NgModule({
  declarations: [
    ContactLoaderComponent
  ],
  imports: [
    CommonModule
  ],
  exports: [
    ContactLoaderComponent
  ]
})
export class ContactLoaderModule { }
