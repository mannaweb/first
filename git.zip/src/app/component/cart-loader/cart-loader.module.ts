import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CartLoaderComponent } from './cart-loader.component';



@NgModule({
  declarations: [
    CartLoaderComponent
  ],
  imports: [
    CommonModule
  ],
  exports: [
    CartLoaderComponent
  ]
})
export class CartLoaderModule { }
