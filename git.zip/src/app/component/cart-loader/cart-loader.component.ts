import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-cart-loader',
  templateUrl: './cart-loader.component.html',
  styleUrls: ['./cart-loader.component.scss'],
	encapsulation:ViewEncapsulation.None
})
export class CartLoaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
