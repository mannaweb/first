import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductDetailsReviewLoaderComponent } from './product-details-review-loader.component';

describe('ProductDetailsReviewLoaderComponent', () => {
  let component: ProductDetailsReviewLoaderComponent;
  let fixture: ComponentFixture<ProductDetailsReviewLoaderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProductDetailsReviewLoaderComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductDetailsReviewLoaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
