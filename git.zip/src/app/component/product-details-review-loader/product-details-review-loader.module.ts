import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProductDetailsReviewLoaderComponent } from './product-details-review-loader.component';



@NgModule({
  declarations: [
    ProductDetailsReviewLoaderComponent
  ],
  imports: [
    CommonModule
  ],
  exports: [
    ProductDetailsReviewLoaderComponent
  ]
})
export class ProductDetailsReviewLoaderModule { }
