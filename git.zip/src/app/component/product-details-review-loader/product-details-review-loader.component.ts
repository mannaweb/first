import { Component, OnInit , ViewEncapsulation} from '@angular/core';

@Component({
  selector: 'app-product-details-review-loader',
  templateUrl: './product-details-review-loader.component.html',
  styleUrls: ['./product-details-review-loader.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ProductDetailsReviewLoaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
