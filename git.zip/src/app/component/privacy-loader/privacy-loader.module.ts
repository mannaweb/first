import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PrivacyLoaderComponent } from './privacy-loader.component';


@NgModule({
  declarations: [
    PrivacyLoaderComponent
  ],
  imports: [
    CommonModule
  ],
  exports:[
    PrivacyLoaderComponent
  ]
})
export class PrivacyLoaderModule { }
