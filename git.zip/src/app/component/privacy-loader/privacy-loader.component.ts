import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-privacy-loader',
  templateUrl: './privacy-loader.component.html',
  styleUrls: ['./privacy-loader.component.scss']
})
export class PrivacyLoaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
