import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PrivacyLoaderComponent } from './privacy-loader.component';

describe('PrivacyLoaderComponent', () => {
  let component: PrivacyLoaderComponent;
  let fixture: ComponentFixture<PrivacyLoaderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PrivacyLoaderComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PrivacyLoaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
