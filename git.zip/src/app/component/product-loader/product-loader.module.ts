import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProductLoaderComponent } from './product-loader.component';



@NgModule({
  declarations: [
    ProductLoaderComponent
  ],
  imports: [
    CommonModule
  ],
  exports:[
    ProductLoaderComponent
  ]
})
export class ProductLoaderModule { }
