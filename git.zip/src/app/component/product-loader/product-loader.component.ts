import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-product-loader',
  templateUrl: './product-loader.component.html',
  styleUrls: ['./product-loader.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ProductLoaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
