import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SpecialityLoaderComponent } from './speciality-loader.component';



@NgModule({
  declarations: [
    SpecialityLoaderComponent
  ],
  imports: [
    CommonModule
  ],
  exports:[
    SpecialityLoaderComponent
  ]
})
export class SpecialityLoaderModule { }
