import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-speciality-loader',
  templateUrl: './speciality-loader.component.html',
  styleUrls: ['./speciality-loader.component.scss']
})
export class SpecialityLoaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
