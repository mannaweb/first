import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SpecialityLoaderComponent } from './speciality-loader.component';

describe('SpecialityLoaderComponent', () => {
  let component: SpecialityLoaderComponent;
  let fixture: ComponentFixture<SpecialityLoaderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SpecialityLoaderComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SpecialityLoaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
