import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about-loader',
  templateUrl: './about-loader.component.html',
  styleUrls: ['./about-loader.component.scss']
})
export class AboutLoaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
