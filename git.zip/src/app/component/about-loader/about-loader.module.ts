import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AboutLoaderComponent } from './about-loader.component';



@NgModule({
  declarations: [
    AboutLoaderComponent
  ],
  imports: [
    CommonModule
  ],
  exports:[
    AboutLoaderComponent
  ]
})
export class AboutLoaderModule { }
