import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AboutLoaderComponent } from './about-loader.component';

describe('AboutLoaderComponent', () => {
  let component: AboutLoaderComponent;
  let fixture: ComponentFixture<AboutLoaderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AboutLoaderComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AboutLoaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
