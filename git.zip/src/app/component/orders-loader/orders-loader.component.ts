import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-orders-loader',
  templateUrl: './orders-loader.component.html',
  styleUrls: ['./orders-loader.component.scss'],
	encapsulation:ViewEncapsulation.None
})
export class OrdersLoaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
