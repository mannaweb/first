import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OrdersLoaderComponent } from './orders-loader.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';



@NgModule({
  declarations: [
    OrdersLoaderComponent
  ],
  imports: [
    CommonModule,
		NgbModule
  ],
  exports: [
    OrdersLoaderComponent
  ]
})
export class OrdersLoaderModule { }
