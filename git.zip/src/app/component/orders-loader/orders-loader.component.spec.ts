import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OrdersLoaderComponent } from './orders-loader.component';

describe('OrdersLoaderComponent', () => {
  let component: OrdersLoaderComponent;
  let fixture: ComponentFixture<OrdersLoaderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OrdersLoaderComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OrdersLoaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
