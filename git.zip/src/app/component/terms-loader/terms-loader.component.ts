import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-terms-loader',
  templateUrl: './terms-loader.component.html',
  styleUrls: ['./terms-loader.component.scss']
})
export class TermsLoaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
