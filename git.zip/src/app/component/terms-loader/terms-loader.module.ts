import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TermsLoaderComponent } from './terms-loader.component';



@NgModule({
  declarations: [
    TermsLoaderComponent
  ],
  imports: [
    CommonModule
  ],
  exports:[
    TermsLoaderComponent
  ]
})
export class TermsLoaderModule { }
