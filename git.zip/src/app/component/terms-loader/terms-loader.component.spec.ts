import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TermsLoaderComponent } from './terms-loader.component';

describe('TermsLoaderComponent', () => {
  let component: TermsLoaderComponent;
  let fixture: ComponentFixture<TermsLoaderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TermsLoaderComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TermsLoaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
