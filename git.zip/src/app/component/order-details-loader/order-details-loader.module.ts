import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OrderDetailsLoaderComponent } from './order-details-loader.component';



@NgModule({
  declarations: [
    OrderDetailsLoaderComponent
  ],
  imports: [
    CommonModule
  ],
  exports: [
    OrderDetailsLoaderComponent
  ]
})
export class OrderDetailsLoaderModule { }
