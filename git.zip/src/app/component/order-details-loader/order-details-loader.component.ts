import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-order-details-loader',
  templateUrl: './order-details-loader.component.html',
  styleUrls: ['./order-details-loader.component.scss'],
	encapsulation:ViewEncapsulation.None
})
export class OrderDetailsLoaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
