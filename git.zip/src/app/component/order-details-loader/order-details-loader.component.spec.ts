import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OrderDetailsLoaderComponent } from './order-details-loader.component';

describe('OrderDetailsLoaderComponent', () => {
  let component: OrderDetailsLoaderComponent;
  let fixture: ComponentFixture<OrderDetailsLoaderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OrderDetailsLoaderComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OrderDetailsLoaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
