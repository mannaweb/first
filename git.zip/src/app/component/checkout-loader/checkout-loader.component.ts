import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-checkout-loader',
  templateUrl: './checkout-loader.component.html',
  styleUrls: ['./checkout-loader.component.scss'],
	encapsulation:ViewEncapsulation.None
})
export class CheckoutLoaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
