import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CheckoutLoaderComponent } from './checkout-loader.component';

describe('CheckoutLoaderComponent', () => {
  let component: CheckoutLoaderComponent;
  let fixture: ComponentFixture<CheckoutLoaderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CheckoutLoaderComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CheckoutLoaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
