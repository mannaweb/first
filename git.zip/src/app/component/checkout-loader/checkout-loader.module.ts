import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CheckoutLoaderComponent } from './checkout-loader.component';



@NgModule({
  declarations: [
    CheckoutLoaderComponent
  ],
  imports: [
    CommonModule
  ],
  exports: [
    CheckoutLoaderComponent
  ]
})
export class CheckoutLoaderModule { }
