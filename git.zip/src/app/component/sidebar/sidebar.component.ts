import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { EventsService } from '../../services/events.service';

@Component({
	selector: 'app-sidebar',
	templateUrl: './sidebar.component.html',
	styleUrls: ['./sidebar.component.scss'],
	encapsulation: ViewEncapsulation.None
})
export class SidebarComponent implements OnInit {
	sideToggleClass: any = '';
	element: any = '';
	constructor(public router: Router, private events: EventsService) { }

	ngOnInit(): void {
	}

	logout() {
		localStorage.removeItem('user_id');
		localStorage.removeItem('user_role');
		this.events.publishSomeData({
			type: 'login',
			userId: ''
		});
		this.router.navigate(['/']);
	}

	sidebarToggle() {
		if (this.sideToggleClass == '') {
			this.sideToggleClass = 'collapsed';
			this.element = document.querySelector('.user-page');
			this.element.classList.toggle('collapsed');
		} else {
			this.sideToggleClass = '';
			this.element = document.querySelector('.user-page');
			this.element.classList.toggle('collapsed');
		}
	}

}
