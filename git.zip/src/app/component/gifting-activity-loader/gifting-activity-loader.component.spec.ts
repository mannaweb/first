import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GiftingActivityLoaderComponent } from './gifting-activity-loader.component';

describe('GiftingActivityLoaderComponent', () => {
  let component: GiftingActivityLoaderComponent;
  let fixture: ComponentFixture<GiftingActivityLoaderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GiftingActivityLoaderComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GiftingActivityLoaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
