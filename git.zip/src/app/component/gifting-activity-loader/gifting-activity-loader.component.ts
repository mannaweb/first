import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-gifting-activity-loader',
  templateUrl: './gifting-activity-loader.component.html',
  styleUrls: ['./gifting-activity-loader.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class GiftingActivityLoaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
