import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GiftingActivityLoaderComponent } from './gifting-activity-loader.component';


@NgModule({
  declarations: [
    GiftingActivityLoaderComponent
  ],
  imports: [
    CommonModule
  ],
  exports: [
    GiftingActivityLoaderComponent
  ]
})
export class GiftingActivityLoaderModule { }
