import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { ApiService } from '../../services/api.service';

@Component({
  selector: 'app-default-footer',
  templateUrl: './default-footer.component.html',
  styleUrls: ['./default-footer.component.scss'],
	encapsulation:ViewEncapsulation.None
})
export class DefaultFooterComponent implements OnInit {
  userId=localStorage.getItem('user_id');
  settingsData:any = [];
  constructor(
    public router:Router,
    public apiService: ApiService,
  ) { }

  ngOnInit(): void {
    this.getSettings();
  }

  getSettings(){
    this.apiService.postData('settings',{id:1}).subscribe((result)=>{
      if (result['status'] == 200) {
        this.settingsData = result['data'];
      }
    },(error)=>{
      console.log(error);
    })
  }

}
