import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { EventsService } from '../../services/events.service';
import { Router } from '@angular/router';
import { ApiService } from '../../services/api.service';

@Component({
  selector: 'app-default-header',
  templateUrl: './default-header.component.html',
  styleUrls: ['./default-header.component.scss'],
	encapsulation:ViewEncapsulation.None
})

export class DefaultHeaderComponent implements OnInit {
  userId=localStorage.getItem('user_id');
  countCart:any='0';
  settingsData:any = [];
  is_search:any = 2;
  searchList:any = [];
  //searchDefaultImage:any ='assets/img/google-css-spinner-800x600_sm.gif';
  constructor(
    public router:Router,
    private events: EventsService,
    public apiService: ApiService,
  ) {
    this.events.getObservable().subscribe((data) => {
			if(data.type == 'login'){
				this.userId = data.userId
			}
      if(data.type == 'cart-total-count'){
				this.countCart = data.countCart
			}
		});
  }

  ngOnInit(): void {
    this.getCartData();
    this.getSettings();
  }

  getCartData(){
    if(this.userId !='' && this.userId !=null){
      this.apiService.postData('total-cart-item',{userId:this.userId}).subscribe((result)=>{
        if (result['status'] == 200) {
          this.countCart = result['data'].total;
        }
      },(error)=>{
        console.log(error);
      })
    }else{
      this.countCart = 0;
    }
  }

  searchString(keyword:any){ 
    //this.searchDefaultImage ='assets/img/google-css-spinner-800x600_sm.gif'; 
		if(keyword == ''){
			this.is_search = 2;
      this.searchList = [];
		}else{
			this.apiService.postData('product/list',{'keyword':keyword}).subscribe((result)=>{
			this.searchList = result['data'];	      
			this.is_search = 1;
			},(error)=>{
				console.log(error);
			})
		}
  }

  getSettings(){
    this.apiService.postData('settings',{id:1}).subscribe((result)=>{
      if (result['status'] == 200) {
        this.settingsData = result['data'];
      }
    },(error)=>{
      console.log(error);
    })
  }

  getLink(id:any){
    this.is_search = 2;
    this.searchList = [];
    window.open('product-details?product='+id);
  }

  openLink(link:any){
    window.open(link, '_blank');
  }

  logout(){
		localStorage.removeItem('user_id');
    localStorage.removeItem('user_role');
    this.events.publishSomeData({
			type:'login',
			userId: ''
		});
		this.router.navigate(['/']);
	}

}
