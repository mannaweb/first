export const environment = {
  production: true,
  apiurl: 'https://topgift.iosx.in//api/',
  userDefaultImg: 'assets/img/default-user.jpg',
  productDefaultImg: 'assets/img/no-image.jpg',
  giftImage:'assets/img/gift.png',
  contactImage: 'assets/img/contact.png'
};
